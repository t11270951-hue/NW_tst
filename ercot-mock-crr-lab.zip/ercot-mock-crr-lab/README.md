# ERCOT Mock CRR Lab (Starter)

Minimal Next.js app with Tailwind + Recharts to show a Congestion ($/MW) chart.

## Quick start

```bash
npm install
npm run dev
```

Visit http://localhost:3000/congestion
